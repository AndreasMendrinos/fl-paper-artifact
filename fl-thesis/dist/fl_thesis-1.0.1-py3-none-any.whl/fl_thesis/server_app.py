"""pytorchexample: A Flower / PyTorch app."""

#import torch
from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord
from flwr.serverapp import Grid, ServerApp
from flwr.serverapp.strategy import FedAvg

from fl_thesis.task import Net, load_centralized_dataset, test

from datetime import datetime
from pathlib import Path


app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""
    print("SERVER MAIN STARTED", flush=True)
    import torch
    # Read run config
    num_rounds: int = context.run_config["num-server-rounds"]
    learning_rate: float = context.run_config["learning-rate"]
    fraction_train: float = context.run_config["fraction-train"]
    fraction_evaluate: float = context.run_config["fraction-evaluate"]

    # Initialize global model
    global_model = Net()
    arrays = ArrayRecord(global_model.state_dict())

    # Initialize strategy
    strategy = FedAvg(
        fraction_train=fraction_train,
        fraction_evaluate=fraction_evaluate,
    )

    # Create output directory for this run
    current_time = datetime.now()
    run_dir = current_time.strftime("%Y-%m-%d/%H-%M-%S")
    save_path = Path.cwd() / "outputs" / run_dir
    save_path.mkdir(parents=True, exist_ok=True)

    # Start federated training
    result = strategy.start(
        grid=grid,
        initial_arrays=arrays,
        train_config=ConfigRecord({"learning-rate": learning_rate}),
        num_rounds=num_rounds,
        evaluate_fn=global_evaluate,
    )

    # Save final model
    final_model_path = save_path / "final_model.pt"
    state_dict = result.arrays.to_torch_state_dict()
    torch.save(state_dict, final_model_path)

    print(f"\nFinal model saved to: {final_model_path}")



def global_evaluate(server_round: int, arrays: ArrayRecord) -> MetricRecord:
    """Evaluate model on centralized test data."""
    import torch
    # Load global model
    model = Net()
    model.load_state_dict(arrays.to_torch_state_dict())

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # Load centralized test set
    test_dataloader = load_centralized_dataset()

    # Evaluate global model
    test_loss, test_acc = test(model, test_dataloader, device)

    # Return evaluation metrics
    return MetricRecord(
        {
            "accuracy": test_acc,
            "loss": test_loss,
        }
    )


